# Trade-up
Family, business, bartering, nettwork
